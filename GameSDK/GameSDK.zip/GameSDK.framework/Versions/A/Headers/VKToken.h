//
//  VKToken.h
//  letsgame
//
//  Created by king on 15/10/29.
//
//

#import <Foundation/Foundation.h>

@interface VKToken : NSObject
@property(nonatomic,retain) NSString *token;
@property(nonatomic,retain) NSString *uid;

@end
