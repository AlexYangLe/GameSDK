//
//  LSGAppDelegate.h
//  letsgameDemo
//
//  Created by zhy on 14-5-24.
//
//

#import <UIKit/UIKit.h>

@interface LSGAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
