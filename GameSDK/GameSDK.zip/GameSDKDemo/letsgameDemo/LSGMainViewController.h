//
//  LSGMainViewController.h
//  letsgameDemo
//
//  Created by zhy on 14-5-24.
//
//

#import <UIKit/UIKit.h>

@interface LSGMainViewController : UIViewController

@end
