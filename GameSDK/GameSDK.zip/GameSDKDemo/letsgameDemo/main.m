//
//  main.m
//  letsgameDemo
//
//  Created by zhy on 14-5-24.
//
//

#import <UIKit/UIKit.h>

#import "LSGAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([LSGAppDelegate class]));
    }
}
